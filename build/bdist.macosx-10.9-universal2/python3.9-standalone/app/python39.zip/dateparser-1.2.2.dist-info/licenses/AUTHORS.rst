=======
Credits
=======

Currently, more than 100 committers have contributed to this project, making this
contributors list really hard to maintain, so we have decided to stop updating
this list.

To see the people behind this code, you can run ``git shortlog -s -n`` or visit the
contributions section in Github: https://github.com/scrapinghub/dateparser/graphs/contributors

We really appreciate **all the people that has contributed to this project with their
time and ideas**. Special mention to **Waqas Shabir** (waqasshabbir), **Eugene Amirov**
(Allactaga) and **Artur Sadurski** (asadurski) for creating and maintaining this awesome
project.

To all of you... thank you for building and improving this!
